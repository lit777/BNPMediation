library(testthat)
library(BNPMediation)

test_check("BNPMediation")
